#include <Arduino.h>
#include "AudioTools.h"
#include "BluetoothA2DPSink.h"

// ======================================================
//  NÚCLEOS
//  Núcleo 0: Bluetooth + lectura de la manivela (ADC)
//  Núcleo 1: juego de LEDs / buzzer
// ======================================================
static const BaseType_t NUCLEO_BT    = 0;
static const BaseType_t NUCLEO_JUEGO = 1;

// ======================================================
//  CAJA MUSICAL (Bluetooth + manivela)
//  Girar la manivela -> PLAY.  Dejar de girar -> PAUSE.
//  NO prender con la manivela girando (calibra el reposo al arrancar).
// ======================================================
AnalogAudioStream out;               // DAC interno: GPIO25
BluetoothA2DPSink a2dp_sink(out);

// ---------- Configuración ----------
const int      PIN_ADC      = 34;    // ADC1_CH6, solo entrada
const float    DIVISOR      = 1.0;   // sin divisor (R2 retirada)
const int      ON_MV        = 1;     // sobre el reposo -> girando
const float    OFF_MV       = 0.5;   // sobre el reposo -> quieta
const uint32_t ON_MS        = 200;   // girando este tiempo -> PLAY
const uint32_t OFF_MS       = 2000;  // quieta este tiempo   -> PAUSE
const uint32_t PERIODO_MS   = 20;    // una lectura cada 20 ms
const float    SUAVE        = 0.15;  // filtro: más bajo = más suave y más lento
const uint32_t REINTENTO_MS = 2000;  // reenvío si el celular no hizo caso
const uint8_t  MAX_INTENTOS = 4;
const uint32_t IMPRIMIR_MS  = 100;

// ---------- Estado ----------
float    filtrado = 0;
int      reposo = 0;
bool     girando = false;
uint32_t tInicioCambio = 0;
uint32_t tUltimoComando = 0, tImprimir = 0;
bool     quieroSonar = false;
uint8_t  intentos = 0;

enum Reproduccion { DESCONOCIDA, REPRODUCIENDO, PAUSADA };
volatile Reproduccion celular = DESCONOCIDA;   // lo que informa el celular (AVRCP)
volatile bool streamActivo = false;            // respaldo si el celular no informa

// ---------- Callbacks del Bluetooth ----------
void alCambiarConexion(esp_a2d_connection_state_t st, void*) {
  Serial.printf("Bluetooth: %s\n", a2dp_sink.to_str(st));
  if (st == ESP_A2D_CONNECTION_STATE_DISCONNECTED) {
    streamActivo = false;
    celular = DESCONOCIDA;
  }
}

void alCambiarAudio(esp_a2d_audio_state_t st, void*) {
  streamActivo = (st == ESP_A2D_AUDIO_STATE_STARTED);
}

void alCambiarPlay(esp_avrc_playback_stat_t st) {
  if (st == ESP_AVRC_PLAYBACK_PLAYING) celular = REPRODUCIENDO;
  else if (st == ESP_AVRC_PLAYBACK_PAUSED || st == ESP_AVRC_PLAYBACK_STOPPED) celular = PAUSADA;
  Serial.printf("Celular: %s\n", celular == REPRODUCIENDO ? "REPRODUCIENDO" : "PAUSADO");
}

bool estaSonando() {
  if (celular != DESCONOCIDA) return celular == REPRODUCIENDO;
  return streamActivo;   // el celular no manda su estado: usar el stream
}

// ---------- ADC ----------
int leerMv() {
  uint32_t suma = 0;
  for (int i = 0; i < 8; i++) suma += analogReadMilliVolts(PIN_ADC);
  return suma / 8;
}

void tareaBluetooth(void*) {
  analogReadResolution(12);
  analogSetPinAttenuation(PIN_ADC, ADC_0db);    // rango ~0 - 0,95 V

  // Calibrar el reposo (manivela quieta)
  uint32_t suma = 0;
  for (int i = 0; i < 50; i++) { suma += leerMv(); vTaskDelay(pdMS_TO_TICKS(10)); }
  reposo = suma / 50;
  filtrado = reposo;
  Serial.printf("Reposo: %d mV en el pin\n", reposo);
  if (reposo > 60) Serial.println("OJO: reposo alto. Revisar divisor/D1-D2 o no girar al prender.");

  a2dp_sink.set_on_connection_state_changed(alCambiarConexion);
  a2dp_sink.set_on_audio_state_changed(alCambiarAudio);
  a2dp_sink.set_avrc_rn_playstatus_callback(alCambiarPlay);   // antes de start()
  a2dp_sink.set_auto_reconnect(true);
  a2dp_sink.start("Mesa sensorial MAFE");
  a2dp_sink.set_volume(80);
  Serial.printf("Bluetooth en nucleo %d\n", xPortGetCoreID());
  Serial.println("Listo: conectate a 'Mesa Sensorial MAFE' desde el celular");

  for (;;) {
    uint32_t ahora = millis();

    // 1) Leer y filtrar
    filtrado += SUAVE * (leerMv() - filtrado);
    int senal = (int)filtrado - reposo;

    // 2) Decidir si la manivela está girando (con tiempo de confirmación)
    bool cambia = girando ? (senal < OFF_MV) : (senal > ON_MV);
    if (cambia) {
      if (tInicioCambio == 0) tInicioCambio = ahora;
      if (ahora - tInicioCambio >= (girando ? OFF_MS : ON_MS)) {
        girando = !girando;
        tInicioCambio = 0;
        quieroSonar = girando;
        intentos = 0;
        tUltimoComando = ahora - REINTENTO_MS;   // actuar ya
        Serial.printf(">>> %s (senal %d mV)\n", girando ? "GIRANDO" : "QUIETA", senal);
      }
    } else {
      tInicioCambio = 0;
    }

    // 3) Mandar PLAY / PAUSE solo si el celular no está como queremos
    if (a2dp_sink.is_connected() && estaSonando() != quieroSonar) {
      if (intentos < MAX_INTENTOS && ahora - tUltimoComando >= REINTENTO_MS) {
        if (quieroSonar) a2dp_sink.play(); else a2dp_sink.pause();
        tUltimoComando = ahora;
        intentos++;
        Serial.printf("Comando: %s (intento %d)\n", quieroSonar ? "PLAY" : "PAUSE", intentos);
      }
    } else {
      intentos = 0;
    }

    // 4) Monitor (sirve también con el Serial Plotter)
    if (ahora - tImprimir >= IMPRIMIR_MS) {
      tImprimir = ahora;
      Serial.printf("senal_mV:%d on:%d off:%.1f motor_V:%.2f girando:%d sonando:%d\n",
                    senal, ON_MV, OFF_MV, filtrado * DIVISOR / 1000.0, (int)girando, (int)estaSonando());
    }

    vTaskDelay(pdMS_TO_TICKS(PERIODO_MS));
  }
}

// ======================================================
//  JUEGO DE LEDS (Simon)
//  Orden de índices: 0 = rojo, 1 = verde, 2 = azul, 3 = amarillo
//  Arranca con el primer botón. Sin pulsaciones por 30 s -> se apaga
//  y vuelve a esperar un botón para empezar de nuevo.
//  Si se falla una secuencia, el siguiente intento muestra una pista:
//  el LED del botón correcto da destellos breves (PWM).
// ======================================================
const int LEDS[4]  = {22, 21, 19, 18};   // rojo, verde, azul, amarillo
const int BTS[4]   = {39, 35, 32, 33};   // botón 1 rojo, 2 verde, 3 azul, 4 amarillo
const int buzzer   = 23;
const int TONOS[4] = {262, 330, 392, 523};

// Canales LEDC (API de Arduino-ESP32 2.x).
// Canal 0 = buzzer. Los LEDs usan 2..5: el canal 1 se deja libre porque comparte
// timer con el 0, y ledcWriteTone cambia la frecuencia de ese timer.
const int CANAL_BUZZER  = 0;
const int CANAL_LED[4]  = {2, 3, 4, 5};

const int LED_FULL        = 255;         // brillo normal (de 0 a 255)

// Pista (destello del botón correcto tras un fallo)
const int      LED_DESTELLO      = 127;   // brillo del destello (0-255). Sube para más luz
const uint32_t DESTELLO_ON_MS    = 120;  // duración de cada destello
const uint32_t DESTELLO_PERIODO  = 1600;  // un destello cada 800 ms

const uint32_t INACTIVIDAD_MS = 30000;   // sin tocar ningún botón -> se apaga el juego

const int MAX_SEC = 20;
int secuencia[MAX_SEC];
int largo     = 1;     // pasos en uso
int velocidad = 600;   // ms por paso (más alto = más lento)
uint32_t msSinTocar = 0;   // tiempo acumulado esperando al jugador sin pulsación
bool pista = false;        // true tras fallar: el botón correcto da destellos

void ledSet(int i, int brillo) {
  ledcWrite(CANAL_LED[i], brillo);
}

void apagarTodo() {
  for (int i = 0; i < 4; i++) ledSet(i, 0);
  ledcWriteTone(CANAL_BUZZER, 0);
}

void encenderPaso(int i) {
  ledSet(i, LED_FULL);
  ledcWriteTone(CANAL_BUZZER, TONOS[i]);
}

void esperarSuelte(int b) {
  unsigned long t = millis();
  while (millis() - t < 100) {                       // 100 ms seguidos en LOW
    if (digitalRead(BTS[b]) == 1) t = millis();      // si rebota, reinicia
    vTaskDelay(1);
  }
}

void mostrarSecuencia() {
  vTaskDelay(pdMS_TO_TICKS(800));
  for (int k = 0; k < largo; k++) {
    encenderPaso(secuencia[k]);
    vTaskDelay(pdMS_TO_TICKS(velocidad));
    apagarTodo();
    vTaskDelay(pdMS_TO_TICKS(velocidad / 3));
  }
}

// Devuelve: índice del botón (0-3), -1 si pasa timeoutMs sin pulsar,
// o -2 si se acumularon INACTIVIDAD_MS sin ninguna pulsación (apagar juego).
// El tiempo de mostrar la secuencia no cuenta como inactividad.
// Si ledDestello >= 0, ese LED da destellos mientras se espera (pista).
// Quien llama debe apagar los LEDs después (apagarTodo).
int esperarBoton(unsigned long timeoutMs, int ledDestello = -1) {
  unsigned long t0 = millis();
  unsigned long tPrev = t0;
  bool destelloEncendido = false;
  while (millis() - t0 < timeoutMs) {
    unsigned long n = millis();
    msSinTocar += n - tPrev;
    tPrev = n;
    if (msSinTocar >= INACTIVIDAD_MS) return -2;

    // Destello periódico del botón correcto
    if (ledDestello >= 0) {
      bool debeEncender = ((n - t0) % DESTELLO_PERIODO) < DESTELLO_ON_MS;
      if (debeEncender != destelloEncendido) {
        destelloEncendido = debeEncender;
        ledSet(ledDestello, debeEncender ? LED_DESTELLO : 0);
      }
    }

    for (int i = 0; i < 4; i++) {
      if (digitalRead(BTS[i]) == 1) {
        msSinTocar = 0;
        return i;
      }
    }
    vTaskDelay(1);
  }
  msSinTocar += millis() - tPrev;
  return (msSinTocar >= INACTIVIDAD_MS) ? -2 : -1;
}

void celebrar() {
  for (int i = 0; i < 4; i++) ledSet(i, LED_FULL);
  ledcWriteTone(CANAL_BUZZER, 523);
  vTaskDelay(pdMS_TO_TICKS(300));
  apagarTodo();
}

// Espera (con todo apagado) a que se presione un botón para iniciar.
void esperarInicio() {
  apagarTodo();
  Serial.println("Juego en espera: presiona un boton para iniciar");

  // Si algún botón ya está presionado, esperar a que lo suelten
  for (;;) {
    bool alguno = false;
    for (int i = 0; i < 4; i++) if (digitalRead(BTS[i]) == 1) alguno = true;
    if (!alguno) break;
    vTaskDelay(pdMS_TO_TICKS(10));
  }

  int b = -1;
  while (b == -1) {
    for (int i = 0; i < 4; i++) {
      if (digitalRead(BTS[i]) == 1) { b = i; break; }
    }
    vTaskDelay(pdMS_TO_TICKS(5));
  }

  esperarSuelte(b);                    // este toque solo inicia, no cuenta como respuesta
  vTaskDelay(pdMS_TO_TICKS(300));
}

// Una partida completa. Termina cuando hay 30 s sin pulsaciones.
void jugarPartida() {
  largo = 1;
  velocidad = 600;
  msSinTocar = 0;
  pista = false;
  secuencia[0] = random(0, 4);
  Serial.println("Juego iniciado");

  for (;;) {
    mostrarSecuencia();

    bool acierto = true;
    for (int pos = 0; pos < largo; pos++) {
      // Tras un fallo, el botón correcto da destellos mientras se espera
      int b = esperarBoton(10000, pista ? secuencia[pos] : -1);
      Serial.printf("pos %d: leyó %d, esperaba %d\n", pos, b, secuencia[pos]);

      if (b == -2) {                   // 30 s sin tocar -> apagar el juego
        apagarTodo();
        Serial.println("Juego apagado por inactividad (30 s)");
        return;
      }
      if (b == -1) {                   // 10 s sin tocar
        apagarTodo();
        acierto = false;
        break;
      }

      apagarTodo();                    // quita el destello antes de mostrar la pulsación
      encenderPaso(b);
      esperarSuelte(b);
      apagarTodo();

      if (b != secuencia[pos]) { acierto = false; break; }
    }

    if (acierto) {
      pista = false;                   // acertó completa: se quita la ayuda
      celebrar();
      largo++;
      if (largo > MAX_SEC) largo = 1;
      secuencia[largo - 1] = random(0, 4);
      velocidad = max(300, velocidad - 50);
    } else {
      pista = true;                    // el próximo intento hace destellar el botón correcto
      velocidad = min(1200, velocidad + 150);   // repite la MISMA secuencia, más lento
      Serial.println("Fallo: el siguiente intento tendra pista");
    }
  }
}

void tareaJuego(void*) {
  // Buzzer
  ledcSetup(CANAL_BUZZER, 2000, 8);
  ledcAttachPin(buzzer, CANAL_BUZZER);
  // LEDs con PWM (5 kHz, 8 bits) para poder atenuarlos
  for (int i = 0; i < 4; i++) {
    ledcSetup(CANAL_LED[i], 5000, 8);
    ledcAttachPin(LEDS[i], CANAL_LED[i]);
    ledSet(i, 0);
    pinMode(BTS[i], INPUT);            // GPIO35 y 39 no tienen pull interno
  }
  randomSeed(esp_random());            // semilla por hardware (no usa el ADC)
  Serial.printf("Juego en nucleo %d\n", xPortGetCoreID());

  for (;;) {
    esperarInicio();                   // espera el primer botón
    jugarPartida();                    // juega hasta 30 s de inactividad
  }
}

// ======================================================
//  ARRANQUE
// ======================================================
void setup() {
  Serial.begin(115200);

  xTaskCreatePinnedToCore(tareaBluetooth, "bt",    10240, nullptr, 2, nullptr, NUCLEO_BT);
  xTaskCreatePinnedToCore(tareaJuego,     "juego",  4096, nullptr, 1, nullptr, NUCLEO_JUEGO);
}

void loop() {
  vTaskDelete(NULL);   // loop() no se usa: todo corre en las dos tareas
}